

#include "processor.h"
#include "linux_parser.h"


float Processor::Utilization() { 
  std::string user = LinuxParser::CpuUtilization()[1];
  std::string nice = LinuxParser::CpuUtilization()[2];
  std::string system = LinuxParser::CpuUtilization()[3];
  std::string idle = LinuxParser::CpuUtilization()[4];
  std::string iowait = LinuxParser::CpuUtilization()[5];
  std::string irq = LinuxParser::CpuUtilization()[6];
  std::string softirq = LinuxParser::CpuUtilization()[7];
  std::string steal = LinuxParser::CpuUtilization()[8];
  std::string guest = LinuxParser::CpuUtilization()[9];
  std::string guest_nice = LinuxParser::CpuUtilization()[10];
  float idle_ = std::stof(idle);
  float iowait_ = std::stof(iowait);
  float Idle = idle_ + iowait_;
  
  float user_ = std::stof(user);
  float nice_ = std::stof(nice);
  float system_ = std::stof(system);
  float irq_ = std::stof(irq);
  float softirq_ = std::stof(softirq);
  float steal_ = std::stof(steal);
  float NonIdle = user_ + nice_ + system_ + irq_ + softirq_ + steal_;
  
  float Total = Idle + NonIdle;
  
  float cpu_percentage = NonIdle / Total;
  
  
  
  return cpu_percentage; }