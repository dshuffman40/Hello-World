#include <dirent.h>
#include <unistd.h>
#include <string>
#include <vector>

#include "linux_parser.h"

using std::stof;
using std::string;
using std::to_string;
using std::vector;


string LinuxParser::OperatingSystem() {
  string line;
  string key;
  string value;
  std::ifstream filestream(kOSPath);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::replace(line.begin(), line.end(), ' ', '_');
      std::replace(line.begin(), line.end(), '=', ' ');
      std::replace(line.begin(), line.end(), '"', ' ');
      std::istringstream linestream(line);
      while (linestream >> key >> value) {
        if (key == "PRETTY_NAME") {
          std::replace(value.begin(), value.end(), '_', ' ');
          return value;
        }
      }
    }
  }
  return value;
}


string LinuxParser::Kernel() {
  string os, kernel;
  string line;
  std::ifstream stream(kProcDirectory + kVersionFilename);
  if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> os >> kernel;
  }
  return kernel;
}


vector<int> LinuxParser::Pids() {
  vector<int> pids;
  DIR* directory = opendir(kProcDirectory.c_str());
  struct dirent* file;
  while ((file = readdir(directory)) != nullptr) {
    // Is this a directory?
    if (file->d_type == DT_DIR) {
      // Is every character of the name a digit?
      string filename(file->d_name);
      if (std::all_of(filename.begin(), filename.end(), isdigit)) {
        int pid = stoi(filename);
        pids.push_back(pid);
      }
    }
  }
  closedir(directory);
  return pids;
}


float LinuxParser::MemoryUtilization() { 
  string line;
  string key;
  float value;
  vector<int> values;
  std::ifstream filestream(kProcDirectory + kStatDirectory);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      while (linestream >> key >> value) {    
          values.push_back(value);
        
      }
    }
  }
  float MemUsed = values[0] - values[1];
  float percentage = MemUsed / values[0];
  return percentage;
}


long LinuxParser::UpTime() { 
  string uptime, other;
  string line;
  std::ifstream stream(kProcDirectory + kUptimeFilename);
  if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> uptime >> other;
  }
  return std::stol(uptime);
} 


long LinuxParser::Jiffies() { return 0; }


long LinuxParser::ActiveJiffies(int pid[[maybe_unused]]) { return 0; }


long LinuxParser::ActiveJiffies() { return 0; }


long LinuxParser::IdleJiffies() { return 0; }


vector<string> LinuxParser::CpuUtilization() { 
  vector<string> cpuString;
  string line;
  string key;
  std::ifstream filestream(kProcDirectory + kStatDirectory);
  if (filestream.is_open()) {
    std::getline(filestream, line);
    std::istringstream linestream(line);
    while (linestream >> key){
      cpuString.push_back(key);
    }
  }
  return cpuString;
}

/// Override Function
vector<string> LinuxParser::CpuUtilization(int pid) { 
  vector<string> cpuString;
  string line;
  string key;
  std::ifstream filestream(kProcDirectory + to_string(pid) + kStatDirectory);
  if (filestream.is_open()) {
    std::getline(filestream, line);
    std::istringstream linestream(line);
    while (linestream >> key){
      cpuString.push_back(key);
    }
  }
  return cpuString;
}



int LinuxParser::TotalProcesses() { 
  string line;
  string key;
  int value;
  std::ifstream filestream(kProcDirectory + kStatDirectory);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      while (linestream >> key >> value) {
        if (key == "processes") {
          
          return value;
        }
      }
    }
    
  }
  
return value;
}


int LinuxParser::RunningProcesses() { 
  
  string line;
  string key;
  int value;
  std::ifstream filestream(kProcDirectory + kStatDirectory);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      while (linestream >> key >> value) {
        if (key == "procs_running") {
          
          return value;
        }
      }
    }
  }
    return value; 
 }
  



string LinuxParser::Command(int pid) { 
  string line;
  string full = "";
  std::ifstream filestream(kProcDirectory + to_string(pid) + kCmdlineFilename);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)){
      full = full + line;
    }
    
    
  }
  return full;
  
}


string LinuxParser::Ram(int pid) { 
  string line;
  string key;
  string value;
  std::ifstream filestream(kProcDirectory + to_string(pid) +  kStatusFilename);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      while (linestream >> key >> value) {
        if (key == "VmSize:") {
          int v_int = stoi(value);
          v_int = v_int / 1000;
          string strValue = to_string(v_int);
          return strValue;
        }
      }
    }
  }
    return value; 
}


string LinuxParser::Uid(int pid) { 
  string line;
  string key;
  string value;
  std::ifstream filestream(kProcDirectory + to_string(pid) + kStatDirectory);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      while (linestream >> key >> value) {
        if (key == "Uid:") {
          
          return value;
        }
      }
    }
  }
    return value;  }


string LinuxParser::User(int pid) { 
string line;
  string key;
  string value;
  string val2;
  std::ifstream filestream(kPasswordPath);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::replace(line.begin(), line.end(), ':', ' ');
      std::replace(line.begin(), line.end(), 'x', ' ');
      std::istringstream linestream(line);
      while (linestream >> value >> key) {
        if (key == Uid(pid)) {
          return value;
        }
      }
    }
  }
  return value;  
}


long LinuxParser::UpTime(int pid[[maybe_unused]]) { return 0; }