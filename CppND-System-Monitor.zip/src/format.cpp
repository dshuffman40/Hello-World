#include <string>

#include "format.h"

using std::string;


string Format::ElapsedTime(long seconds) { 
    double hr = seconds / 3600.000000;
  	int Hr = hr;
    string hour = std::to_string(Hr);
  	double leftover1 = hr - Hr;
  	double min = leftover1 * 60.000000;
    string minutes = std::to_string(int(min));
  	double leftover2 = min - int(min);
  	double secon = leftover2 * 60.000000;
  	string secs = std::to_string(int(secon));
  	if (Hr < 10)
      hour = "0" + hour;
  	if (min < 10)
      minutes = "0" + minutes;
  	if (int(secon) < 10)
      secs = "0" + secs;
  	string time = hour + ":" + minutes + ":" + secs;
    return time; }