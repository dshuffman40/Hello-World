#include <unistd.h>
#include <cctype>
#include <sstream>
#include <string>
#include <vector>

#include "process.h"

using std::string;
using std::to_string;
using std::vector;

///constructor
Process::Process(int p): pId_(p) {}

int Process::Pid() { 
  
  return this->pId_; }


float Process::CpuUtilization() { 
  long uptime = LinuxParser::UpTime();
  string utime_Str = LinuxParser::CpuUtilization(this->pId_)[13];
  string stime_Str = LinuxParser::CpuUtilization(this->pId_)[14];
  string cutime_Str = LinuxParser::CpuUtilization(this->pId_)[15];
  string cstime_Str = LinuxParser::CpuUtilization(this->pId_)[16];
  string starttime_str = LinuxParser::CpuUtilization(this->pId_)[21];
  float utime = stof(utime_Str);
  float stime = stof(stime_Str);
  float cutime = stof(cutime_Str);
  float cstime = stof(cstime_Str);
  float starttime = stof(starttime_str);
  float total_time = utime + cutime + stime + cstime;
  float seconds = uptime - (starttime / sysconf(_SC_CLK_TCK));
  float cpu_usage =  ((total_time / sysconf(_SC_CLK_TCK)) / seconds);
  cPu = cpu_usage;
  return cPu;
  }


string Process::Command() { return LinuxParser::Command(this->pId_); }


string Process::Ram() { return LinuxParser::Ram(this->pId_); }


string Process::User() { return LinuxParser::User(this->pId_); }


long int Process::UpTime() { 
  string starttime_str = LinuxParser::CpuUtilization(this->pId_)[21];
  long int start = stol(starttime_str) / sysconf(_SC_CLK_TCK);
  
  return start; }


bool Process::operator<(Process const& a) const { 
  	
  	return a.cPu < this->cPu;
   }